terms = int(input("Enter the number of terms: "))

if terms <= 0:
    print("Please enter a positive number of terms.")
else:
    first, second = 0, 1
    print("Fibonacci sequence:")

    for _ in range(terms):
        print(first, end=" ")
        first, second = second, first + second
    print()
