# Python Basic Programs

A collection of five beginner-friendly Python programs for practising fundamental programming concepts.

## Programs

| No. | File | Description | Concepts |
| --- | --- | --- | --- |
| 1 | `01_area_of_circle.py` | Calculates the area of a circle from its radius. | Input, arithmetic, `math.pi` |
| 2 | `02_even_or_odd.py` | Checks whether an integer is even or odd. | `if-else`, modulus operator (`%`) |
| 3 | `03_factorial_recursion.py` | Calculates a non-negative integer's factorial using recursion. | Functions, recursion, base case |
| 4 | `04_count_vowels_consonants.py` | Counts the vowels and consonants in a string. | Strings, loops, conditional statements |
| 5 | `05_fibonacci_sequence.py` | Prints the Fibonacci sequence for the requested number of terms. | Loops, variable assignment |

## Requirements

- Python 3
- No third-party packages are required.

## How to run

1. Download or clone this repository.
2. Open the project folder in a terminal or VS Code.
3. Run the required file using Python. For example:

   ```bash
   python 01_area_of_circle.py
   ```

   Replace the filename with any of the other program filenames to run another exercise.

## Example runs

### 1. Area of a circle

```text
Enter the radius of the circle: 5
Area of the circle: 78.54
```

### 2. Even or odd

```text
Enter an integer: 8
8 is an even number.
```

### 3. Factorial using recursion

```text
Enter a non-negative integer: 5
Factorial of 5 is: 120
```

### 4. Count vowels and consonants

```text
Enter a string: Hello World
Number of vowels: 3
Number of consonants: 7
```

### 5. Fibonacci sequence

```text
Enter the number of terms: 7
Fibonacci sequence:
0 1 1 2 3 5 8
```

## Learning note

These examples are intended for beginner practice. Each program is kept in a separate file so it can be run and studied independently.
