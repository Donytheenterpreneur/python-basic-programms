def factorial(number):
    """Return the factorial of a non-negative integer using recursion."""
    if number < 0:
        raise ValueError("Factorial is not defined for negative numbers.")
    if number == 0 or number == 1:
        return 1
    return number * factorial(number - 1)


try:
    value = int(input("Enter a non-negative integer: "))
    print(f"Factorial of {value} is: {factorial(value)}")
except ValueError as error:
    print(error)
