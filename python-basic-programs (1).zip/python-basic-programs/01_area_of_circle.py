import math

radius = float(input("Enter the radius of the circle: "))

if radius < 0:
    print("Radius cannot be negative.")
else:
    area = math.pi * radius ** 2
    print(f"Area of the circle: {area:.2f}")
